package data_manager;
import java.text.DecimalFormat;

public class Function2 extends Function {
	
	DecimalFormat dF2 = new DecimalFormat("##.00");

	@Override
	public double fnValue(double x) {
		if(x < 0 || x > 4)
			return Double.MAX_VALUE;
		else 
			return x/3.0 + 2*Math.sqrt(Math.pow(x, 2) - 8 * x + 25);
	}

	@Override
	public double getXVal(double x) {
		return x;
	}

	@Override
	public double getYVal(double x) {
		return Math.sqrt(9+Math.pow(4-x, 2));
	}

	@Override
	public double getZVal(double x) {
		return 5;
	}
	
	@Override
	public String answerString(double optVal, double x, double y, double z) {
		return "The optimal distance for the function is " + dF2.format(optVal) + " meters when AB is " + dF2.format(x) + " and BC is " + dF2.format(y) + " and AC is " + dF2.format(z);
	}
	
	public String toString() {
		return "Find the most optimal path for the dog to reach the ball";
	}

}
