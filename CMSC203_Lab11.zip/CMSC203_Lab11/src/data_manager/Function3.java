package data_manager;

import java.text.DecimalFormat;

public class Function3 extends Function {

	DecimalFormat dF1 = new DecimalFormat("##.0");
	DecimalFormat dF2 = new DecimalFormat("##.00");

	@Override
	public double fnValue(double x) {
		return Math.sqrt((Math.pow(x, 4) - Math.pow(x, 2) + 1));
	}

	@Override
	public double getXVal(double x) {
		return x;
	}

	@Override
	public double getYVal(double x) {
		return Math.pow(x, 2);
	}

	@Override
	public double getZVal(double x) {
		return -1;
	}
	
	@Override
	public String answerString(double optVal, double x, double y, double z) {
		return "The closest point P to point Q is (0"   + dF1.format(x) + ", " + dF1.format(y) + ") or (-0" + dF1.format(x) + ", " + dF1.format(y) + "). The distance between these two points is 0" + dF2.format(optVal);
	}
	
	public String toString() {
		return "Find the closest point to point Q(0,1) on the graph y = x^2";
	}

}
