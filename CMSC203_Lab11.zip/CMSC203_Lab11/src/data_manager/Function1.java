package data_manager;
import java.text.DecimalFormat;


public class Function1 extends Function{
	
	DecimalFormat dF2 = new DecimalFormat("##.00");
	
	@Override 
	public double fnValue(double x) {
		if (x <= 0.0) 
			return Double.MAX_VALUE;
		else 
			return (0.8* Math.PI * Math.pow(x, 2) + 800/x);
	}
	
	@Override
	public String toString() {
		return "Minimize the cost of a can that will hold 2 liters of liquid";
	}
	
	@Override
	public String answerString(double cost, double radius, double height, double z) {
		return "The minimized cost of the can is $" + dF2.format(cost) + " when the radius is " + dF2.format(radius) + "cm and the height being " + dF2.format(height) + "cm";
	}
	
	@Override
	public double getXVal(double x) {
		return x;
	}
	
	@Override
	public double getYVal(double x) {
		return (2000/ (Math.PI * Math.pow(x, 2)));
	}
	
	@Override
	public double getZVal(double x) {
		return -1.0;
	}
}
