package dataElement;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

/**
 * Class: CMSC 203
 * Instructor: Dr. Grinberg
 * Description:
 * This file manages what happens to every ticket object and creates the data used by the GUI
 * Due: 05/03/2020
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. 
 * I have not given my code to any student. Print your Name here: Kobie Marsh
 * @author Kobie Marsh
 * 
 */


public class MovieTicketManager implements MovieTicketManagerInterface{
	
	private NumberFormat cF = NumberFormat.getCurrencyInstance(Locale.US);
	private ArrayList<Ticket> ticketList = new ArrayList<Ticket>();
	private double price;

	/**
	 * Default constructor
	 */
	public MovieTicketManager() {
		
	}
	
	/**
	 * Adds a ticket to an arrayList of ticket objects called ticketList
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 * @return price
	 */
	public double addTicket(String movieN, String rating, int d, int t, String f, String type, int id) {
		if(type.equals("Adult")) {
			Adult newTicket = new Adult(movieN, rating, d, t, f, type, id);
			if(f.equals("IMAX"))
				newTicket.setFormat(Format.IMAX);
			else if(f.equals("3D"))
				newTicket.setFormat(Format.THREE_D);
			else
				newTicket.setFormat(Format.NONE);
			price = newTicket.calculateTicketPrice();
			ticketList.add(new Adult(movieN, rating, d, t, newTicket.getFormat(), type, id, price));
		}
		else if(type.equals("Child")) {
			Child newTicket = new Child(movieN, rating, d, t, f, type, id);
			if(f.equals("IMAX"))
				newTicket.setFormat(Format.IMAX);
			else if(f.equals("3D"))
				newTicket.setFormat(Format.THREE_D);
			else
				newTicket.setFormat(Format.NONE);
			price = newTicket.calculateTicketPrice();
			ticketList.add(new Child(movieN, rating, d, t, newTicket.getFormat(), type, id, price));
		}
		else if(type.equals("Employee")) {
			Employee newTicket = new Employee(movieN, rating, d, t, f, type, id);
			
			if(f.equals("IMAX"))
				newTicket.setFormat(Format.IMAX);
			else if(f.equals("3D"))
				newTicket.setFormat(Format.THREE_D);
			else
				newTicket.setFormat(Format.NONE);
			
			if(numVisits(newTicket.getId()) >= 2)
				price = newTicket.calculateTicketPrice();
			else
				price = 0;
			
			ticketList.add(new Employee(movieN, rating, d, t, newTicket.getFormat(), type, id, price));
		}
		else if(type.equalsIgnoreCase("MoviePass")) {
			MoviePass newTicket = new MoviePass(movieN, rating, d, t, f, type, id);
			
			if(f.equals("IMAX"))
				newTicket.setFormat(Format.IMAX);
			else if(f.equals("3D"))
				newTicket.setFormat(Format.THREE_D);
			else
				newTicket.setFormat(Format.NONE);
			
			if(numMoviesToday(newTicket.getId(), newTicket.getDate()) < 1 && numThisMovie(newTicket.getId(), newTicket.getMovie()) < 1 && newTicket.getFormat() == Format.NONE) {
				if(numVisits(newTicket.getId()) < 1)
					price = 9.99;
				else
					price = 0.00;
			}
			else 
				price = newTicket.calculateTicketPrice();
			ticketList.add(new MoviePass(movieN, rating, d, t, newTicket.getFormat(), type, id, price));
			
		}
		return price;
	}
	
	/**
	 * Gets all 3D tickets from ticketList and returns their toStrings
	 * @return threeDTickets
	 */
	public ArrayList<String> get3DTickets() {
		ArrayList<String> threeDTickets = new ArrayList<String>();
		sortByDay();
		for(int i = 0; i < ticketList.size(); i++) {
			if(ticketList.get(i).getFormat() == Format.THREE_D)
				threeDTickets.add(ticketList.get(i).toString());
		}
		
		return threeDTickets;
	}
	
	/**
	 * Gets all tickets from ticketList and returns their toStrings
	 * @return allTickets
	 */
	public ArrayList<String> getAllTickets(){
		ArrayList<String> allTickets = new ArrayList<String>();
		sortByDay();
		for(int i = 0; i < ticketList.size(); i++) {
			allTickets.add(ticketList.get(i).toString());
		}
		return allTickets;
	}
	
	/**
	 * Gets all MoviePass tickets from ticketList and returns their toStrings
	 * @return moviePassTickets
	 */
	public ArrayList<String> getMoviePassTickets(){
		ArrayList<String> moviePassTickets = new ArrayList<String>();
		sortById();
		for(int i = 0; i < ticketList.size(); i++) {
			if(ticketList.get(i).getType().equalsIgnoreCase("Moviepass"))
				moviePassTickets.add(ticketList.get(i).toString());
		}
		return moviePassTickets;
	}
	
	/**
	 * Splits the totals of each ticket type and shows a string with all the data
	 * @return salesReport
	 */
	public String monthlySalesReport() {
		int numOfAdult = 0, numOfChild = 0, numOfEmp = 0, numOfPass = 0;
		double adultSales = 0.0, childSales = 0.0, empSales = 0.0, passSales = 0.0;
		String salesReport;
		for(int i = 0; i < ticketList.size(); i++) {
			if(ticketList.get(i).getType().equalsIgnoreCase("adult")) {
				numOfAdult++;
				adultSales+=ticketList.get(i).getPrice();
			}
			else if(ticketList.get(i).getType().equalsIgnoreCase("child")) {
				numOfChild++;
				childSales+=ticketList.get(i).getPrice();
			}
			else if(ticketList.get(i).getType().equalsIgnoreCase("employee")) {
				numOfEmp++;
				empSales+=ticketList.get(i).getPrice();
			}
			else {
				numOfPass++;
				passSales+=ticketList.get(i).getPrice();
			}
		}
		
		salesReport = "   Monthly Sales Report"
			+ "\n"
			+ "\n"
			+ "\t\t\tSales\tNumber\n"
			+ "ADULT\t\t"+cF.format(adultSales)+ "\t" + numOfAdult + "\n" 
			+ "CHILD\t\t"+cF.format(childSales)+ "\t" + numOfChild + "\n" 
			+ "EMPLOYEE\t"+cF.format(empSales)+ "\t" + numOfEmp + "\n" 
			+ "MOVIEPASS\t"+cF.format(passSales)+ "\t" + numOfPass 
			+ "\n"
			+ "\n"
			+ "Total Monthly Sales: "+cF.format(totalSalesMonth());
		
		return salesReport;
	}

	/**
	 * Shows how many times a person has watched movies in a given day
	 * @param id
	 * @param date
	 * @return moviesToday
	 */
	public int numMoviesToday(int id, int date) {
		int moviesToday = 0;
		
		for(int i = 0; i < ticketList.size(); i++) {
			if(ticketList.get(i).getDate() == date && ticketList.get(i).getId() == id)
				moviesToday++;
		}
		
		return moviesToday;
	}
	
	/**
	 * Shows how many times a person has seen a movie
	 * @param id
	 * @param movie
	 * @return numThisMovie
	 */
	public int numThisMovie(int id, String movie){
		int numThisMovie = 0;
		
		for(int i = 0; i < ticketList.size(); i++) {
			if(ticketList.get(i).getId() == id && ticketList.get(i).getMovie().equals(movie)) 
				numThisMovie++;
		}
		
		return numThisMovie;
	}
	
	/**
	 * Shows how many times a person has come to the movie theater
	 * @param id
	 * @return numVisits
	 */
	public int numVisits(int id) {
		int numVisits = 0;
		
		for(int i = 0; i< ticketList.size(); i++) {
			if(ticketList.get(i).getId() == id)
				numVisits++;
		}
		
		return numVisits;
	}
	
	/**
	 * Reads a file and inputs the information into the ticketList arrayList
	 * @param file
	 */
	public void readFile(File file) {
		try (Scanner read = new Scanner(file)){
			while(read.hasNextLine()) {
				String line = read.nextLine();
				String[] vals = line.split(":");
				addTicket(vals[0], vals[1], Integer.parseInt(vals[2]), Integer.parseInt(vals[3]), vals[4], vals[5], Integer.parseInt(vals[6]));
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Sort ticketList by day attended going from day 1 - 31
	 */
	private void sortByDay() {	
		Ticket temp;
		   for (int i = 1; i <ticketList.size(); i++) {
		    for (int j = i; j > 0; j--) {
		     if (ticketList.get(j).getDate() < ticketList.get(j-1).getDate()) {
		    	 if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
		    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
		    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
		    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
		    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
		    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
		    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
		    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
		    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
		    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
		    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
		    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
		    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
		    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
		    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
		    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
		    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
		    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
		    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
		    	 }
		    	 
		     }
		    }
		   }
	}
	
	/**
	 * Sorts ticketList by ID number ascending from least to greatest
	 */
	private void sortById() {
		Ticket temp;
		for (int i = 1; i <ticketList.size(); i++) {
			for (int j = i; j > 0; j--) {
				if (ticketList.get(j).getId() < ticketList.get(j-1).getId()) {
			    	 if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
			    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
			    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
			    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("adult") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
			    		 temp = new Adult(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Adult(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
			    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
			    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
			    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("child") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
			    		 temp = new Child(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Child(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
			    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
			    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
			    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("employee") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
			    		 temp = new Employee(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new Employee(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("adult")) {
			    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Adult(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("child")) {
			    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Child(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("employee")) {
			    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new Employee(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 else if(ticketList.get(j).getType().equalsIgnoreCase("moviepass") && ticketList.get(j-1).getType().equalsIgnoreCase("moviepass")) {
			    		 temp = new MoviePass(ticketList.get(j).getMovie(), ticketList.get(j).getRating(), ticketList.get(j).getDate(), ticketList.get(j).getT(), ticketList.get(j).getFormat(), ticketList.get(j).getType(), ticketList.get(j).getId(), ticketList.get(j).getPrice());
			    		 ticketList.set(j,new MoviePass(ticketList.get(j-1).getMovie(), ticketList.get(j-1).getRating(), ticketList.get(j-1).getDate(), ticketList.get(j-1).getT(), ticketList.get(j-1).getFormat(), ticketList.get(j-1).getType(), ticketList.get(j-1).getId(), ticketList.get(j-1).getPrice()));
			    		 ticketList.set(j-1,new MoviePass(temp.getMovie(), temp.getRating(), temp.getDate(), temp.getT(), temp.getFormat(), temp.getType(), temp.getId(), temp.getPrice()));
			    	 }
			    	 
			     }
			}
		}
	}
	
	/**
	 * Shows how much money was made in sales during the given month
	 * @return total
	 */
	public double totalSalesMonth() {
		double total = 0.0;
		for(int i = 0; i < ticketList.size(); i++) {
			total+= ticketList.get(i).getPrice();
		}
		return total;
	}

}

