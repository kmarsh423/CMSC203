package dataElement;


import java.text.NumberFormat;
import java.util.Locale;

/**
 * Class: CMSC 203
 * Instructor: Dr. Grinberg
 * Description:
 * This defines the MoviePass object which extends Ticket
 * Due: 05/03/2020
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. 
 * I have not given my code to any student. Print your Name here: Kobie Marsh
 * @author Kobie Marsh
 * 
 */
public class MoviePass extends Ticket{

	
	private NumberFormat cF = NumberFormat.getCurrencyInstance(Locale.US);
	private Format format;
	private String movieN, rating, f, type;
	private int d, t, id;
	private double ticketPrice;
	private final double ADULT_D = 10.5, ADULT_N = 13.5, TAX = 0.096, IMAX_P = 3, THREED_P = 2.5;
	
	/**
	 * This is a constructor for the MoivePass object
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 */
	public MoviePass(String movieN, String rating, int d, int t, String f, String type, int id) {
		this.movieN = movieN;
		this.rating = rating;
		this.d = d;
		this.t= t;
		this.f = f;
		this.type = type;
		this.id = id;
		
	}

	/**
	 * This is the constructor for the object MoviePass that is put in the ticketList arrayList located in MovieTicketManager 
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 * @param price
	 */
	public MoviePass(String movieN, String rating, int d, int t, Format f, String type, int id, double price) {
		this.movieN = movieN;
		this.rating = rating;
		this.d = d;
		this.t = t;
		this.format = f;
		this.type = type;
		this.id = id;
		this.ticketPrice = price;
	}

	/**
	 * This calculates the price of the MoviePass ticket - if it doesn't qualify for the MoviePass discount
	 * @return ticketPrice
	 */
	@Override
	public double calculateTicketPrice() {
		if(t < 18) {
			if(format == Format.IMAX) {
				ticketPrice = (ADULT_D + IMAX_P) + (ADULT_D + IMAX_P)*TAX;
			}
			else if(format == Format.THREE_D) {
				ticketPrice = (ADULT_D + THREED_P) + (ADULT_D + THREED_P)*TAX;
			}
			else
				ticketPrice = ADULT_D + ADULT_D*TAX;
		}
		else if(t >= 18) {
			if(format == Format.IMAX) {
				ticketPrice = (ADULT_N + IMAX_P) + (ADULT_N + IMAX_P)*TAX;
			}
			else if(format == Format.THREE_D) {
				ticketPrice = (ADULT_N + THREED_P) + (ADULT_N + THREED_P)*TAX;
			}
			else
				ticketPrice = ADULT_N + ADULT_N*TAX;
		}
		return ticketPrice;
	}

	/**
	 * Gets ID for ticket
	 * @return id
	 */
	@Override
	public int getId() {
		return id;
	}

	/**
	 * Gets movie name
	 * @return movieN
	 */
	public String getMovie() {
		return movieN;
	}

	/**
	 * Sets the movie name in the ticket
	 * @param movieN
	 */
	public void setMovieN(String movieN) {
		this.movieN = movieN;
	}

	/**
	 * Gets the rating of the ticket
	 * @return rating
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * Sets the rating in the ticket
	 * @param rating
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}

	/**
	 * Gets the String format
	 * @return f
	 */
	public String getF() {
		return f;
	}

	/**
	 * Sets the string format
	 * @param f
	 */
	public void setF(String f) {
		this.f = f;
	}

	/**
	 * Gets the type of ticket
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type of ticket
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the date
	 * @return date
	 */
	public int getDate() {
		return d;
	}

	/**
	 * Sets the date
	 * @param d
	 */
	public void setD(int d) {
		this.d = d;
	}

	/**
	 * Gets the time
	 * @return t
	 */
	public int getT() {
		return t;
	}

	/**
	 * Sets the time
	 * @param t
	 */
	public void setT(int t) {
		this.t = t;
	}

	/**
	 * Gets ticket price
	 * @return ticketPrice
	 */
	public double getTicketPrice() {
		return ticketPrice;
	}

	/**
	 * Sets ticket price
	 * @param ticketPrice
	 */
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	/**
	 * Sets ID 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Creates a string that shows the values of the object
	 * @return MoviePass information
	 */
	@Override
	public String toString() {
		//If the format is nothing
		if(format == Format.NONE) 
			return "MOVIEPASS-" + id + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(ticketPrice);
		//If the format is THREE_D, looks better if its "3D" than "THREE_D" 
		else if(format == Format.THREE_D)
			return "MOVIEPASS-" + id + " " + "3D" + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(ticketPrice);
		//For Imax
		else
			return "MOVIEPASS-" + id + " " + format + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(ticketPrice);
	}

	/**
	 * Sets enum format
	 * @param format
	 */
	@Override
	public void setFormat(Format format) {
		this.format = format;
	}

	/**
	 * Gets enum format
	 * @return format
	 */
	@Override
	public Format getFormat() {
		return format;
	}
	
	/**
	 * Gets ticket price
	 * @return ticketPrice
	 */
	@Override
	public double getPrice() {
		return ticketPrice;
	}

	
	

}
