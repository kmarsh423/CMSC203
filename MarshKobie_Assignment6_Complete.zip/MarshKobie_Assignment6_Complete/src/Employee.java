package dataElement;


import java.text.NumberFormat;
import java.util.Locale;

/**
 * Class: CMSC 203
 * Instructor: Dr. Grinberg
 * Description:
 * This defines the Employee object which extends Ticket
 * Due: 05/03/2020
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. 
 * I have not given my code to any student. Print your Name here: Kobie Marsh
 * @author Kobie Marsh
 * 
 */
public class Employee extends Ticket{

	private NumberFormat cF = NumberFormat.getCurrencyInstance(Locale.US);
	private Format format;
	private String movieN, rating, f, type;
	private int d, t, id;
	private double ticketPrice;
	private final double TAX_RATE = 0.096, IMAX_P = 3.00, THREED_P = 2.50;
	
	public Employee() {
		
	}
	
	/**
	 * This is a constructor for the Employee object
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 */
	public Employee(String movieN, String rating, int d, int t, String f, String type, int id) {
		this.movieN = movieN;
		this.rating = rating;
		this.d = d;
		this.t= t;
		this.f = f;
		this.type = type;
		this.id = id;
	}
	
	/**
	 * This is the constructor for the object Employee that is put in the ticketList arrayList located in MovieTicketManager 
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 * @param price
	 */
	public Employee(String movieN, String rating, int d, int t, Format f, String type, int id, double price) {
		this.movieN = movieN;
		this.rating = rating;
		this.d = d;
		this.t = t;
		this.format = f;
		this.type = type;
		this.id = id;
		this.ticketPrice = price;
	}
	
	/**
	 * Gets enum format
	 * @return format
	 */
	public Employee(Format format) {
		this.format = format;
	}
	
	/**
	 * Gets movie name
	 * @return movieN
	 */
	@Override
	public String getMovie() {
		return movieN;
	}

	/**
	 * Sets movie name
	 * @param movieN
	 */
	public void setMovieN(String movieN) {
		this.movieN = movieN;
	}

	/**
	 * Gets the rating of the ticket
	 * @return rating
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * Sets the rating in the ticket
	 * @param rating
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}

	/**
	 * Gets the String format
	 * @return f
	 */
	public String getF() {
		return f;
	}

	/**
	 * Sets the string format
	 * @param f
	 */
	public void setF(String f) {
		this.f = f;
	}

	/**
	 * Gets the type of ticket
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type of ticket
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the date
	 * @return date
	 */
	@Override
	public int getDate() {
		return d;
	}
	
	/**
	 * This calculates the price of the Employee ticket - if it is more than second time watching a movie
	 * @return ticketPrice
	 */
	@Override
	public double calculateTicketPrice() {
		
		if(t < 18) {
			if(format == Format.IMAX) {
				ticketPrice = ((10.5+IMAX_P)/2) + (((10.5+IMAX_P)/2) * TAX_RATE);
			}
			else if(format == Format.THREE_D) {
				ticketPrice = ((10.5+THREED_P)/2) + (((10.5+THREED_P)/2) * TAX_RATE);
				}
			else {
				ticketPrice = 10.5/2 + (10.5*TAX_RATE)/2;
				}
		}
		else if(t >= 18) {
			if(format == Format.IMAX) {
				ticketPrice = ((13.5+IMAX_P)/2) + (((13.5+IMAX_P)/2) * TAX_RATE);		
				}
			else if(format == Format.THREE_D) {
				ticketPrice = ((13.5+THREED_P)/2) + (((13.5+THREED_P)/2) * TAX_RATE);
			}
			else {
				ticketPrice = 13.5/2 + (13.5*TAX_RATE)/2;		
			}
		}
	
		return ticketPrice;
	}

	/**
	 * Sets the date
	 * @param d
	 */
	public void setD(int d) {
		this.d = d;
	}

	/**
	 * Gets the time
	 * @return t
	 */
	public int getT() {
		return t;
	}

	/**
	 * Sets the time
	 * @param t
	 */
	public void setT(int t) {
		this.t = t;
	}

	/**
	 * Sets ID 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets ID
	 * @return id
	 */
	@Override
	public int getId() {
		return id;
	}

	/**
	 * Creates a string that shows the values of the object
	 * @return Employee information
	 */
	@Override
	public String toString(){
		if(format == Format.NONE) 
			return "EMPLOYEE-" + id + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(ticketPrice);
		else if(format == Format.THREE_D)
			return "EMPLOYEE-" + id + " " + "3D" + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(ticketPrice);
		else
			return "EMPLOYEE-" + id + " " + format + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(ticketPrice);
	}

	/**
	 * Gets enum format
	 * @return format
	 */
	@Override
	public Format getFormat() {
		return format;
	}

	/**
	 * Sets enum format
	 * @param format
	 */
	@Override
	public void setFormat(Format format) {
		this.format = format;
	}

	/**
	 * Gets ticket price
	 * @return ticketPrice
	 */
	@Override
	public double getPrice() {
		return ticketPrice;
	}

	
}
