package dataElement;

/**
 * Class: CMSC 203
 * Instructor: Dr. Grinberg
 * Description:
 * This is the abstract object Ticket which all other objects derive from
 * Due: 05/03/2020
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. 
 * I have not given my code to any student. Print your Name here: Kobie Marsh
 * @author Kobie Marsh
 * 
 */

public abstract class Ticket {
	
	/**
	 * Calculates the ticket price
	 * @return price
	 */
	public abstract double calculateTicketPrice();
	
	/**
	 * Gets ID
	 * @return id
	 */
	public abstract int getId();
	
	/**
	 * Ticket object basic constructor
	 */
	public Ticket() {
		
	}
	
	/**
	 * Ticket object constructor
	 * @param format
	 */
	public Ticket(Format format) {
		
	}
	
	/**
	 * Creates String of object
	 * @return String
	 */
	public abstract String toString();
	
	/**
	 * Gets format
	 * @return format
	 */
	public abstract Format getFormat();
	
	/**
	 * Sets format
	 * @param format
	 */
	public abstract void setFormat(Format format);

	/**
	 * gets type of ticket
	 * @return type
	 */
	public abstract String getType();

	/**
	 * Gets date
	 * @return d
	 */
	public abstract int getDate();

	/**
	 * Gets name of movie
	 * @return movieN
	 */
	public abstract String getMovie();
	
	/**
	 * Gets price
	 * @return price
	 */
	public abstract double getPrice();

	/**
	 * Sets date
	 * @param d
	 */
	public abstract void setD(int d);

	/**
	 * Sets id
	 * @param id
	 */
	public abstract void setId(int id);

	/**
	 * Gets rating
	 * @return rating
	 */
	public abstract String getRating();
	
	/**
	 * Sets rating
	 * @param rating
	 */
	public abstract void setRating(String rating);
	
	/**
	 * Gets time
	 * @return t
	 */
	public abstract int getT();
	
	/**
	 * Sets time
	 * @param t
	 */
	public abstract void setT(int t);
	


	

	
	
}
