package dataElement;


import java.text.NumberFormat;
import java.util.Locale;

/**
 * Class: CMSC 203
 * Instructor: Dr. Grinberg
 * Description:
 * This defines the Child object which extends Ticket
 * Due: 05/03/2020
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. 
 * I have not given my code to any student. Print your Name here: Kobie Marsh
 * @author Kobie Marsh
 * 
 */
public class Child extends Ticket{
	
	private NumberFormat cF = NumberFormat.getCurrencyInstance(Locale.US);
	private Format format;
	private String movieN, rating, f, type;
	private int d, t, id;
	private double price;
	private final double CHILD_D = 5.75, CHILD_N = 10.75, TAX = 0.096, IMAX_P = 2, THREED_P = 1.5;
	
	public Child() {
		
	}

	/**
	 * This is a constructor for the Child object
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 */
	public Child(String movieN, String rating, int d, int t, String f, String type, int id) {
		this.movieN = movieN;
		this.rating = rating;
		this.d = d;
		this.t = t;
		this.type = type;
		this.f = f;
		this.id = id;
	}

	/**
	 * This is the constructor for the object Child that is put in the ticketList arrayList located in MovieTicketManager 
	 * @param movieN
	 * @param rating
	 * @param d
	 * @param t
	 * @param f
	 * @param type
	 * @param id
	 * @param price
	 */
	public Child(String movieN, String rating, int d, int t, Format f, String type, int id, double price) {
		this.movieN = movieN;
		this.rating = rating;
		this.d = d;
		this.t = t;
		this.type = type;
		this.format = f;
		this.id = id;
		this.price = price;
	}

	/**
	 * This calculates the price of the Adult ticket
	 * @return price
	 */
	@Override
	public double calculateTicketPrice() {
		if(t < 18) {
			if(format == Format.IMAX) {
				price = (CHILD_D + IMAX_P) + (CHILD_D + IMAX_P)*TAX;
			}
			else if(format == Format.THREE_D) {
				price = (CHILD_D + THREED_P) + (CHILD_D + THREED_P)*TAX;
			}
			else
				price = CHILD_D + CHILD_D*TAX;
		}
		else if(t >= 18) {
			if(format == Format.IMAX) {
				price = (CHILD_N + IMAX_P) + (CHILD_N + IMAX_P)*TAX;
			}
			else if(format == Format.THREE_D) {
				price = (CHILD_N + THREED_P) + (CHILD_N + THREED_P)*TAX;
			}
			else
				price = CHILD_N + CHILD_N*TAX;
		}
		return price;
	}

	/**
	 * Gets movie name
	 * @return movieN
	 */
	@Override
	public String getMovie() {
		return movieN;
	}

	/**
	 * Sets movie name
	 * @param movieN
	 */
	public void setMovieN(String movieN) {
		this.movieN = movieN;
	}

	/**
	 * Gets the rating of the ticket
	 * @return rating
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * Sets the rating in the ticket
	 * @param rating
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}

	/**
	 * Gets the String format
	 * @return f
	 */
	public String getF() {
		return f;
	}

	/**
	 * Sets the string format
	 * @param f
	 */
	public void setF(String f) {
		this.f = f;
	}

	/**
	 * Gets the type of ticket
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type of ticket
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the date
	 * @return date
	 */
	@Override
	public int getDate() {
		return d;
	}

	/**
	 * Sets the date
	 * @param d
	 */
	public void setD(int d) {
		this.d = d;
	}

	/**
	 * Gets the time
	 * @return t
	 */
	public int getT() {
		return t;
	}

	/**
	 * Sets the time
	 * @param t
	 */
	public void setT(int t) {
		this.t = t;
	}

	/**
	 * Gets ticket price
	 * @return ticketPrice
	 */
	@Override
	public double getPrice() {
		return price;
	}

	/**
	 * Sets ID 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets ID
	 * @return id
	 */
	@Override
	public int getId() {
		return id;
	}

	/**
	 * Creates a string that shows the values of the object
	 * @return Employee information
	 */
	@Override
	public String toString() {
		if(format == Format.NONE) 
			return "CHILD" + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(price);
		else if(format == Format.THREE_D)
			return "CHILD " + " " + "3D"  + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(price);
		else
			return "CHILD " + " " + format  + " Movie: " + movieN + " Rating: " + rating + " Day: " + d + " Time: " + t + " Price: " + cF.format(price);
	}

	/**
	 * Gets enum format
	 * @return format
	 */
	@Override
	public Format getFormat() {
		return format;
	}

	/**
	 * Sets enum format
	 * @param format
	 */
	@Override
	public void setFormat(Format format) {
		this.format = format;
		
	}

	/**
	 * Sets the ticket price
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
		
	}

}
