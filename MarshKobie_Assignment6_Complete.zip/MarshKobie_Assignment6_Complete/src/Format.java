package dataElement;
/**
 * Class: CMSC 203
 * Instructor: Dr. Grinberg
 * Description:
 * This enumerated file holds the format of the tickets
 * Due: 05/03/2020
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. 
 * I have not given my code to any student. Print your Name here: Kobie Marsh
 * @author Kobie Marsh
 * 
 */
public enum Format {

	IMAX, THREE_D, NONE;
	
}
